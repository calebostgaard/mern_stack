import React from 'react';
import { useEffect, useState } from 'react';
import { Router } from '@reach/router';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

import Players from './components/Players';
import Games from './components/Games';

function App() {

  const [players, setPlayers] = useState([]);
  useEffect(()=>{
      axios.get('http://localhost:8000/players')
          .then(res=>{
              setPlayers(res.data);
          });
  },[]);

  const removeFromDom = playerId => {
      setPlayers(players.filter(player => player._id != playerId));
  };

  const addToDom = (newPlayer) => {
      setPlayers([...players, newPlayer]);
  };

  return (
    <div className="App">
      <h1><Link to = "/players/list">Manage Players</Link> | <Link to = "/status/game/1">Manage Player Status</Link></h1>
      <hr/>
      <Router>
        <Players path="/players/:item" players={players} removeFromDom={removeFromDom} addToDom={addToDom}/>
        <Games path="/status/:item1/:item2" players={players} />
      </Router>
    </div>
  );
}
export default App;