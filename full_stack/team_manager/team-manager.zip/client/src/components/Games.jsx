import React from 'react';
import { useEffect, useState } from 'react';
import { Router } from '@reach/router';
import axios from 'axios';
import { Link, navigate } from '@reach/router';
import StatusButtons from './StatusButtons';


function Games (props) {
    const { item, players, removeFromDom, addToDom } = props;
    const [playerStatus, setPlayerStatus] = useState(3);

    const changeStatus = (status) => {
        setPlayerStatus(status)
    }



    return (
        <div>
            <h2>Player Status - Game 1</h2>
            <h3>
                <Link to = "/status/game/1">Game 1</Link> | <Link to = "/status/game/1">Game 2</Link> | <Link to = "/status/game/1">Game 3</Link>
            </h3>
            <hr/>
            <table>
                <tr>
                    <th>Player Name</th>
                    <th>Action</th>
                </tr>
                {players && players.map((player, idx)=>
                <tr key={idx}>
                    <td>
                        {player.name}
                    </td>
                    <td>
                        {/* <button 
                        style={{backgroundColor: playerStatus == 1 ? "#90FF62": "#white"}}
                        onClick={(e)=>{changeStatus(1)}}>
                            Playing
                        </button>
                        <button 
                        style={{backgroundColor: playerStatus == 2 ? "#FF6262": "#white"}}
                        onClick={(e)=>{changeStatus(2)}}>
                            Not Playing
                        </button>
                        <button 
                        style={{backgroundColor: playerStatus == 3 ? "#FDFF62": "#white"}}
                        onClick={(e)=>{changeStatus(3)}}>
                            Undecided
                        </button> */}
                        <StatusButtons player={player}/>
                    </td>
                </tr>
                )}
            </table>        </div>
    );
}
export default Games;