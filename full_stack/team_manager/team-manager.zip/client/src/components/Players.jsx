import React from 'react';
import { useEffect, useState } from 'react';
import { Router } from '@reach/router';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

import PlayersList from './PlayersList';
import New from './New';


function Players(props) {
    const { item, players, removeFromDom, addToDom } = props;
    

    return (
        <div className="App">
        <h2><Link to = "/players/list">List</Link> | <Link to = "/players/addplayer">Add Player</Link></h2>
        <hr/>

        {item == "list" ?

        <PlayersList path="/players/list" players={players} removeFromDom={removeFromDom} addToDom={addToDom}/>
        
        :
        item == "addplayer" ?

        <New path="/players/addplayer" addToDom={addToDom}/>
        :
        ""}
        </div>
    );
}
export default Players;