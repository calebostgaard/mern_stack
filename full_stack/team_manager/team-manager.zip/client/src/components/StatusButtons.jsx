import React from 'react';
import { useEffect, useState } from 'react';
import { Router } from '@reach/router';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

function Games (props) {
    const { player } = props;


    return (
        <form>
            <div className="btn-group" role="group">
                <input type="radio" className="btn-check" name="btnradio" id={`${player._id}-active`}autoComplete="off"/>
                <label className="btn btn-outline-success" htmlFor={`${player._id}-active`}>Active</label>
                <input type="radio" className="btn-check" name="btnradio" id={`${player._id}-inactive`} autoComplete="off"/>
                <label className="btn btn-outline-danger" htmlFor={`${player._id}-inactive`}>Inactive</label>
                <input type="radio" className="btn-check" name="btnradio" id={`${player._id}-undecided`} autoComplete="off" defaultChecked/>
                <label className="btn btn-outline-warning" htmlFor={`${player._id}-undecided`}>Undecided</label>
            </div>
        </form> 
    );
}
export default Games;