import React from 'react'
import axios from 'axios';
import { Link, navigate } from '@reach/router';



export default props => {
    const { players, removeFromDom } = props;
    
    // const editLink = (playerId) => {
    //     navigate(`/edit/${playerId}`)
    // }

    const deletePlayer = (playerId, playerName) => {
        var result = window.confirm(`Are you sure you want to delete ${playerName}?`);
        if (result) {
            axios.delete('http://localhost:8000/player/' + playerId)
                .then(res => {
                    removeFromDom(playerId)
                })
        }
    }

    const sortedPlayers = players;
    sortedPlayers.sort(function(a, b) {
        if(a.name.toLowerCase() < b.name.toLowerCase()) return -1;
        if(a.name.toLowerCase() > b.name.toLowerCase()) return 1;
        return 0;
    })

    return (
        <div>
            <table>
                <tr>
                    <th>Team Name</th>
                    <th>Preferred Position</th>
                    <th>Actions</th>
                </tr>
                {sortedPlayers && sortedPlayers.map((player, idx)=>
                <tr key={idx}>
                    <td>
                        {player.name}
                    </td>
                    <td>
                        {player.position}
                    </td>
                    <td>
                        <button style={{backgroundColor: "#FF6262", color: "white"}} onClick={(e)=>{deletePlayer(player._id, player.name)}}>
                            DELETE
                        </button>
                    </td>
                </tr>
                )}
            </table>
        </div>
    )
}


