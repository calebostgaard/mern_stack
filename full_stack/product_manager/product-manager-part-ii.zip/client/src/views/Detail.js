import React, { useEffect, useState } from 'react'
import { Link } from '@reach/router';
import axios from 'axios';
export default props => {
    const [product, setProduct] = useState({})
    useEffect(() => {
        axios.get("http://localhost:8000/product/" + props.id)
            .then(res => setProduct(res.data))
    }, [])
    return (
        <div>
            <h1>{product.title}</h1>
            <p>Price: ${product.price}</p>
            <p>Description: {product.description}</p>
            <Link to = "/products">Go back to Products</Link>
        </div>
    )
}