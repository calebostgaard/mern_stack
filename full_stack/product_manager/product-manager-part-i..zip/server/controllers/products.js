const mongoose = require("mongoose");
const Product = mongoose.model("Product");

module.exports = {
    create: (req, res) => {
        Product.create(req.body)
            .then(product => {
                console.log(product);
                res.json(product);
            })
            .catch(err => {
                console.log(err);
                res.json(err);
            })
    },
    findAll: (req, res) => {
        Product.find()
            .then(products => {
                console.log(products);
                res.json(products);
            })
            .catch(err => {
                console.log(err);
                res.json(err);
            })
    },
    findOne: (req, res) => {
        Product.findOne({_id: req.params.id})
            .then(product => {
                console.log(product);
                res.json(product);
            })
            .catch(err => {
                console.log(err);
                res.json(err);
            })
    },

}

// module.exports.index = (request, response) => {
//     response.json({
//         message: "Hello Product World"
//     });
// }
//     // The method below is new
// module.exports.createProduct = (request, response) => {
//     const { title, price, description } = request.body;
//     Product.create({
//         title,
//         price,
//         description
//     })
//         .then(product => response.json(product))
//         .catch(err => response.json(err));
// }
