const products = require('../controllers/products');

module.exports = (app) => {
    app.get('/products', products.findAll);
    app.post('/products/create', products.create);
    app.get('/product/:id', products.findOne);
}
