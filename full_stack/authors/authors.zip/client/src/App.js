import React from 'react';
import { useEffect, useState } from 'react';
import { Router } from '@reach/router';
import axios from 'axios';

import Detail from './components/Detail';
import Update from './components/Update';
import AuthorList from './components/AuthorList';
import AuthorForm from './components/AuthorForm';
import UnrecognizedID from './components/UnrecognizedID';
function App() {

  const [authors, setAuthors] = useState([]);
  useEffect(()=>{
      axios.get('http://localhost:8000/authors')
          .then(res=>{
              setAuthors(res.data);
          });
  },[]);

  const removeFromDom = authorId => {
      setAuthors(authors.filter(author => author._id != authorId));
  };

  const addToDom = (newAuthor) => {
      setAuthors([...authors, newAuthor]);
  };

  return (
    <div className="App">
      <h1>Favorite Authors</h1>
      <hr/>
      <Router>
        <AuthorList path="/" authors={authors} removeFromDom={removeFromDom}/>
        <AuthorForm path="/new"addToDom={addToDom}/>
        <Detail path="author/:id" />
        <Update path="edit/:id/"/>
      </Router>
    </div>
  );
}
export default App;