import React, { useEffect, useState } from 'react'
import { Link, navigate } from '@reach/router';
import axios from 'axios';
import UnrecognizedID from './UnrecognizedID';
export default props => {
    const { id } = props;
    const [name, setName] = useState(""); 
    const [errors, setErrors] = useState([]); 
    const [exists, setExists] = useState(true);

    useEffect(() => {
        axios.get('http://localhost:8000/author/' + id)
            .then(res => {
                setName(res.data.name);
            })
            .catch( ()=> {
                setExists(false)
            })
    }, [])

    const updateAuthor = e => {
        e.preventDefault();
        axios.put('http://localhost:8000/author/' + id, {
            name: name,
        })
            .then(res => {
                console.log(res);
                navigate(`/author/${id}`)
            })
            .catch(err=> {
                const errorResponse = err.response.data.errors; // Get the errors from err.response.data
                const errorArr = []; // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set Errors
                setErrors(errorArr);
            });
    }

    return (

        exists ?

        <div>
            <p><Link to = "/">Home</Link></p>
            <hr/>
            <h3>Edit this author:</h3>
            <form onSubmit={updateAuthor}>
                {errors.map((err, index) => <p key={index}>{err}</p>)}
                <p>
                    <label>Name</label><br />
                    <input type="text" 
                    name="name" 
                    value={name} 
                    onChange={(e) => { setName(e.target.value) }} />
                </p>
                <input type="submit" />
            </form>
        </div>

        :

        <UnrecognizedID />
        
    )
}
