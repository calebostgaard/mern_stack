import React from 'react'
import axios from 'axios';
import { Link, navigate } from '@reach/router';



export default props => {
    const { removeFromDom } = props;
    
    const editLink = (authorId) => {
        navigate(`/edit/${authorId}`)
    }

    const deleteAuthor = (authorId) => {
        axios.delete('http://localhost:8000/author/' + authorId)
            .then(res => {
                removeFromDom(authorId)
            })
    }

    return (
        <div>
            <p><Link to = "/new">Add an Author</Link></p>
            <hr/>
            <table>
                <tr>
                    <th>Author</th>
                    <th>Actions Available</th>
                </tr>
                {props.authors && props.authors.map((author, idx)=>
                <tr key={idx}>
                    <td>
                        <Link to = {`/author/${author._id}`}>{author.name}   </Link>
                    </td>
                    <td>
                        <button onClick={(e)=>{editLink(author._id)}}>
                            Edit
                        </button>
                        <button onClick={(e)=>{deleteAuthor(author._id)}}>
                            Delete
                        </button>
                    </td>
                </tr>
                )}
            </table>
        </div>
    )
}


