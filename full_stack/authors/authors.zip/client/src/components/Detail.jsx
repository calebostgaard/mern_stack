import React, { useEffect, useState } from 'react'
import { Link, navigate } from '@reach/router';
import axios from 'axios';
import UnrecognizedID from './UnrecognizedID';


export default props => {
    const [author, setAuthor] = useState({})
    const [exists, setExists] = useState(true);

    useEffect(() => {
        axios.get("http://localhost:8000/author/" + props.id)
            .then(res => setAuthor(res.data))
            .catch( ()=> {
                setExists(false)
            })
    }, []);

    const deleteAuthor = () => {
        axios.delete('http://localhost:8000/author/' + props.id)
            .then(res => {
                console.log(res);
                navigate(`/`)
            })
    };

    const editLink = (authorId) => {
        navigate(`/edit/${authorId}`)
    }
    
    return (
        exists ?

        <div>
            <p><Link to = "/">Home</Link></p>
            <hr/>
            <h3>{author.name}</h3>
            <br/>
            <button onClick={(e)=>{editLink(author._id)}}>
                        Edit
            </button>  
            <button onClick={(e)=>{deleteAuthor(author._id)}}>
                        Delete
            </button>
            <br/>
        </div>

        :

        <UnrecognizedID />

    )
}